#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <time.h> //For the random seed

void welcome();
struct map** mapGenerator();
void travelTheMap(struct map**);
void mapDisplayer(struct map** map);
void mapDisplayerF(struct map** map);

struct map {
	int isMine;
	int isFlaged;
	int beenFlaged;
	int mineAmount;
} ;

void main() {
	//welcome();
	srand((unsigned)time(NULL)); //To get the random seed
	struct map** myMap = mapGenerator();
	travelTheMap(myMap);
	mapDisplayerF(myMap);
}

/*
Need to do:
	In func main:
		The malloc will destroyed when leaving the func?
	In func mapInit :
		Initialize every value of the structure map into 0 (maybe don't do it is OK cus its default value is 0);
*/

void welcome() {
	printf("Please adjust the screen to a suitable size:\n");
	for (int cnt = 0; cnt < 25; cnt++) {
		printf("--------------------------------------------------------------------------------\n");
	}
}

void mapDisplayer(struct map** map) {
	printf("0123456789");	//To display x
	for (int i = 0; i < 10; i++) {
		printf("%d", i);	//To display the y
		for (int j = 0; j < 10; j++) {
			
		}
	}


}

struct map** mapGenerator() {	//To generate a map by using struct** and return a pointer
	struct map** mapInit = (struct map**)malloc(sizeof(struct map*) * 10);	//To understand it!!!
	for (int cnt = 0; cnt < 10; cnt++) {
		mapInit[cnt] = (struct map*)malloc(sizeof(struct map) * 10);
		for (int i = 0; i < 10; i++) {	//Initialize the value in the struct
			mapInit[cnt][i].isFlaged = 0;
			mapInit[cnt][i].isMine = 0;
			mapInit[cnt][i].mineAmount = 0;
			mapInit[cnt][i].beenFlaged = 0;
		}
	}

	for (int cnt = 0; cnt < 10;) {	//To generate 10 mines
		int x = rand();	//To generate the location of the mines and frame the location bwtween 0 to 9;
		x %= 10;
		int y = rand();
		y %= 10;
		//printf("\t%d\n", mapInit[x][y].isMine);
		//For test use: to display the loc whether an mine
		if (mapInit[x][y].isMine == 0) {
			mapInit[x][y].isMine = 1;
			cnt++;
		}//To detect the location whether a mine. If the loc isnt a mine then mark it is a mine 
	}

	return mapInit;
}

void travelTheMap(struct map** map) {
	for (int i = 0; i < 10; i++) {
		for (int j = 0; j < 10; j++) {
			if (map[i][j].isMine == 1) printf("%d, %d is a mine.\n", i, j);
		}
	}
}

void mapDisplayerF(struct map** map) {
	printf("  0 1 2 3 4 5 6 7 8 9\n");	//To display x
	for (int i = 0; i < 10; i++) {
		printf("%d", i);	//To display the y
		for (int j = 0; j < 10; j++) {
			if (map[i][j].isMine == 1) {
				printf(" x");
			}
			else if (map[i][j].isMine == 0) {
				printf("  ");
			}
		}
		printf("\n");
	}


}

void mineAmountCounter(struct map** map, int x, int y) {

}
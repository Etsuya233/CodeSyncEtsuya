#ifndef TEST1_LISTPOLYNOMIAL_H
#define TEST1_LISTPOLYNOMIAL_H

#include <stdio.h>
#include <stdlib.h>

typedef struct ListNode{
	struct ListNode* next, *prior;
	double a;
	int b;
} LNode, *List;

List newList(double a, int b, List prior){
	List ret = (List)malloc(sizeof(LNode));
	ret->a = a;
	ret->b = b;
	ret->prior = prior;
	ret->next = NULL;
	return ret;
}

List newStrList(){
	double a;
	int b, n, cnt = 0;
	printf("����������\n");
	scanf("%d", &n);
	printf("���������ʽ����\"ϵ�� ָ��\"�ķ�ʽ����.\n");
    List ret = newList(0, 0, NULL);
    List now = ret;
    List prior = ret;
    while(cnt < n){
        scanf("%lf%d", &a, &b);
        now->next = newList(a, b, prior);
        now->next->prior = prior;
        now = now->next;
        prior = now;
		cnt++;
    }
    return ret;
}

void ListSort(List list){
	List now, min, tp;
	now = list->next;
	while(now){
		min = now;
		tp = now->next;
		while(tp){
			if(tp->b < min->b){
				min = tp;
			}
			tp = tp->next;
		}
		List nowPrior = now->prior, minPrior = min->prior, minNext = min->next;
		nowPrior->next = min;
		minPrior->next = now;
		if(min->next) min->next->prior = now;
		if(now->next) now->next->prior = min;
		min->next = now->next;
		now->next = minNext;
		min->prior = nowPrior;
		now->prior = minPrior;
		now = min->next;
	}
}

void ListPrint(List list){
	list = list->next;
	if(list != NULL){
		printf("%.2fx^%d", list->a, list->b);
		list = list->next;
	}
	while(list){
		printf("+%.2fx^%d", list->a, list->b);
		list = list->next;
	}
	printf("\n");
}

List ListPlus(List a, List b){
	List ret = newList(0, 0, NULL), now = ret;
	a = a->next;
	b = b->next;
	while(a && b){
		if(a->b > b->b){
			now->next = newList(b->a, b->b, NULL);
			b = b->next;
		} else if(a->b < b->b) {
			now->next = newList(a->a, a->b, NULL);
			a = a->next;
		} else {
			now->next = newList(a->a + b->a, a->b, NULL);
			a = a->next;
			b = b->next;
		}
		now = now->next;
	}
	while(a){
		now->next = newList(a->a, a->b, NULL);
		a = a->next;
		now = now->next;
	}
	while(b){
		now->next = newList(b->a, b->b, NULL);
		b = b->next;
		now = now->next;
	}
	return ret;
}

#endif //TEST1_LISTPOLYNOMIAL_H
